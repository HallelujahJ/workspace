##QEMU设备对象模型-QOM
QEMU提供了一套面向对象编程模型—QOM(QEMU Object Module)，几乎所有设备如CPU、内存、总线等都利用QOM来实现。
QOM是对QEMU中对象的一个抽象层，通过QOM可以对QEMU中的各种资源进行抽象、管理。比如设备模拟中的设备创建、配置和销毁。
###QEMU实现对象模型原因
- 各种架构CPU的模拟和实现
QEMU中要实现对各种CPU架构的模拟，而且对于一种架构的CPU，比如X86_64架构的CPU，由于包含的特性不同，也会有不同的CPU模型。任何CPU中都有CPU通用的属性，同时也包含各自特有的属性。为了便于模拟这些CPU模型，面向对象模型必不可少。
- 模拟device和bus的关系
在主板上，一个device会通过bus与其他的device相连接，一个device上可以通过不同的bus端口连接到其他的device，而其他device也可以进一步通过bus与其他设备连接，同时一个bus上也可以连接多个device，这种device连bus、bus连device的关系，qemu需要模拟出来。为了方便模拟设备的这种特性，面向对象的编程模型也是必不可少的。
##QOM数据结构
QOM模型提供了注册类型的框架，包括总线bus、接口interface、设备device等。
QOM创建新类型时需要用到的数据结构包括：类对象ObjectClass、类实例对象Oject、类型对象TypeInfo，基本结构定义在include/qom/object.h，头文件中有详细注释，对数据结构的字段说明和QOM模型的用法。TypeImpl定义在include/qom/object.c中

ObjectClass：所有类对象的基类。
struct ObjectClass
{
    /*< private >*/
    Type type;
    GSList *interfaces;

    const char *object_cast_cache[OBJECT_CLASS_CAST_CACHE];
    const char *class_cast_cache[OBJECT_CLASS_CAST_CACHE];

    ObjectUnparent *unparent;

    GHashTable *properties;
};
Object：所有对象的基类Base Object，第一个成员变量指向ObjectClass。
struct Object
{
    /*< private >*/
    ObjectClass *class;
    ObjectFree *free;
    GHashTable *properties;
    uint32_t ref;
    Object *parent;
};
TypeInfo：定义一个Type的工具型的数据结构。用户定义了一个TypeInfo，然后调用type_register(TypeInfo )或者type_register_static(TypeInfo )函数，就会生成相应的TypeImpl实例，将这个TypeInfo注册到全局的TypeImpl的hash表中，实际上qemu就是通过用户提供的TypeInfo创建的TypeImpl的对象。
struct TypeInfo
{
    const char *name;
    const char *parent;

    size_t instance_size;
    void (*instance_init)(Object *obj);
    void (*instance_post_init)(Object *obj);
    void (*instance_finalize)(Object *obj);

    bool abstract;
    size_t class_size;

    void (*class_init)(ObjectClass *klass, void *data);
    void (*class_base_init)(ObjectClass *klass, void *data);
    void *class_data;

    InterfaceInfo *interfaces;
};
从上面TypeInfo的定义可以归纳出其主要包含了如下几类信息：
1.Name
包括自己的Name，父类parent的Name
2.Class
ObjectClass的信息包括：class_size,class_data,class相关函数 (class_base_init,class_init,class_finalize)。这些函数都是为了初始化，释放结构提ObjectClass
3.Instance
对象Object信息包括：instance_size,instance相关函数(instance_post_init,instance_init,instance_finalize)。这些函数都是为了初始化，释放结构体Object。
4.其他信息
abstract是否为抽象，interface数组

TypeImpl：对数据类型的抽象数据结构，TypeInfo的属性与TypeImpl的属性对应。
struct TypeImpl
{
    const char *name;

    size_t class_size;

    size_t instance_size;

    void (*class_init)(ObjectClass *klass, void *data);
    void (*class_base_init)(ObjectClass *klass, void *data);

    void *class_data;

    void (*instance_init)(Object *obj);
    void (*instance_post_init)(Object *obj);
    void (*instance_finalize)(Object *obj);

    bool abstract;

    const char *parent;
    TypeImpl *parent_type;

    ObjectClass *class;

    int num_interfaces;
    InterfaceImpl interfaces[MAX_INTERFACES];
};
对象的初始化可以分为4步：
1. 将TypeInfo注册TypeImpl
2. 实例化Class(ObjectClass)
3. 实例化Instance(Objec)
4. 添加Property
##QOM模型创建新设备
以下以创建Testchip的SPI设备为例(部分内容源码省略)
使用QOM模型创建新类型时，需要用到以上的ObjectClass、Object和TypeInfo,最后调用type_init宏进行模块注册，这个宏的调用发生在qemu的main函数之前。

创建一个type
#define TYPE_DW_SSI "dw-ssi"
//定义新类型的类和对象的数据结构
typedef struct DW_SSI_State{
	SysBusDevice parent_obj;//父类对象作为该对象数据的结构的第一个属性，以便实现父对象向子对象的cast

	MemoryRegion mmio;
	uint32_t ctrlr0;
	uint32_t ctrlr1;

	qemu_irq cs;
	SSIBUS *ssi;

} DW_SSI_State;
static const TypeInfo dw_ssi_info = {
    .name          = TYPE_DW_SSI,
    .parent        = TYPE_SYS_BUS_DEVICE,
    .instance_size = sizeof(DW_SSI_State),//向系统说明对象的大小，以便系统为对象的实例分配内存
    .class_init    = dw_ssi_class_init,
};
//向系统中注册自定义的新类型
static void dw_ssi_register_types(void)
{
    type_register_static(&dw_ssi_info);
}

type_init(dw_ssi_register_types)
这里调用dw_ssi_register_types函数，以dw_ssi_info为参数调用了type_register_static类型注册函数。目的是利用TypeInfo构造出一个TypeImpl结构，之后插入到一个hash表中，这个hash表以name为key，value就是根据TypeInfo生成的TypeImpl。

Class初始化
在TypeInfo dw_ssi_info结构的定义中，可以看到一个.parent值为TYPE_SYS_BUS_DEVICE,这说明TYPE_DW_SSI的父类型是TYPE_SYS_BUS_DEVICE，即这个spi设备是挂在sysbus总线上的。而TYPE_SYS_BUS_DEVICE的父类是TYPE_DEVICE。依次往上可以得到一条type的链：
TYPE_DW_SSI->TYPE_SYS_BUS_DEVICE->TYPE_DEVICE->TYPE_OBJECT

因此在自定义的新类型中需要新的class初始化函数，并在TypeInfo数据结构中，给TypeInfo的class_init字段赋予该函数的函数指针。
void dw_ssi_class_init(ObjectClass *kclass, void *class_data)
{
	DeviceClass *dc = DEVICE_CLASS(klass);

	dc->reset = dw_ssi_reset;
	dc->realize = dw_ssi_realize;
}
Object的构造
Object的创建由 dw_ssi_realize 函数实现，初始化io地址空间，初始化挂在sysbus上设备的mmio内存空间，初始化中断输入引脚。
static void dw_ssi_realize(DeviceState *dev, Error **errp)
{
	SysBusDevice *sbd = SYS_BUS_DEVICE(dev);
	DW_SSI_State *s = DW_SSI(dev);

	memory_region_init_io(&s->mmio, Object(s), &dw_ssi_ops, s, TYPE_DW_SSI, 0x100);
	sysbus_init_mmio(sdb,&s->mmio);
	sysbus_init_irq(sdb,&s->cs);
}
Object的继承链

DW_SSI_STAT->SysBusDevice->DeviceState->Object

###QOM模型创建新设备流程图

QOM模型创建新设备流程

##编译
在完成了dw_ssi.c文件后，需要添加到 Makefile.objs 中，QEMU好知道编译并将其连接到二进制文件中
common-obj-$(CONFIG_DW_SSI) += dw_ssi.o
配置选项CONFIG_DW_SSI启用后，dw_ssi.c才会被编译并链接到qemu模拟器中。