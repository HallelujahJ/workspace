QEMU简介
QEMU是一款开源的模拟器、仿真器，完全的软件模拟，可以模拟出多种类型的CPU。
QEMU作为一个主机上的VMM(virtual machine monitor)，通过动态二进制转换来模拟CPU，并提供一系列的硬件模型，使guest os认为自己和硬件直接打交道，其实是同QEMU模拟出来的硬件打交道，QEMU再将这些指令翻译给真正硬件进行操作。通过这种模式，guest os可以和主机上的硬盘，网卡，CPU，CD-ROM，音频设备和USB设备进行交互。但由于所有指令都需要经过QEMU来翻译，因而性能会比较差，使用KVM模块进行加速。
KVM是硬件辅助的虚拟化技术，主要负责比较繁琐的CPU和内存虚拟化，而QEMU则负责I/O虚拟化，两者合作，相得益彰。
QEMU主要提供两种功能给用户使用：
	1.用户态模拟器(User-mode emulation)，利用动态代码翻译机制来执行不同于主机架构的代码
	2.全系统模拟(Full-system emulation)，利用其它VMM(Xen,KVM等)来使用硬件提供的虚拟化支持，创建接近于主机性能的虚拟机。
QEMU相关资料
QEMU官网：
https://www.qemu.org/
QEMU源码下载地址：
https://download.qemu.org/qemu-5.0.0.tar.xz
QEMU相关文档：
https://wiki.qemu.org/Documentation
QEMU用户手册：
https://www.qemu.org/docs/master/
QEMU源码下载
1.从源码下载地址下载最新版qemu源码压缩包 qemu-5.0.0.tar.xz。
2.把下载下来的压缩包传到linux服务器(由于公司网络限制，不支持在linux服务器上用其他方式下载源码)。
3.执行解压命令：tar xvf qemu-5.0.0.tar.xz
QEMU源码编译
参考官方文档https://wiki.qemu.org/Hosts/Linux
1.需要python3.7和GCC 4.8的环境
2.重新创建一个工程文件夹
	cd qemu
	mkdir –p bin/debug/native
3.配置QEMU，并编译一个demo，把所有平台都编译出来，耗时长。
	../../../configure --enable-debug
	make
4.针对某一个架构平台编译，在配置时指定target-list参数，选择目标机架构，快速编译指定需要架构即可。
	./configure –target-list=riscv64-softmmu && make
5.运行
/bin/debug/native/x86_64-softmmu/qemu-system-x86_64 –L pc-bios
QEMU运行参数
--help 查看所有运行参数配置
-machine 指定目标机器、开发板。-machine help查看可选项
-bios 指定bios程序路径。可选项：none、pc-bios
-kernel 指定内核
-vnc :1 打开VNC连接端口1
-nographic 关闭图形化界面
-gdb tcp::1234 开启gdbserver指定端口为1234
-s：开启gdbserver，默认端口1234
-S：freeze CPU at startup 配合-s使用
##QEMU调试代码
QEMU自带gdbserver，启动时添加对应参数即可(-s -S)
以下以RISC-V架构下调试zsbl.elf代码为例：
- 用交叉编译工具生成的gdb程序，riscv64-unknown-elf-gdb，基于RSP协议进行远程调试。
- 添加目标架构的描述文件 set tdesc filename
- 连接gdbserver：target remote :1234
- 加载调试代码到gdbserver端：load xxx
- 开始调试

./riscv64-unknown-elf-gdb zsbl.elf
GNU gdb (SiFive GDB 8.3.0-2019.08.0) 8.3
Copyright (C) 2019 Free Software Foundation, Inc.
License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.
Type "show copying" and "show warranty" for details.
This GDB was configured as "--host=x86_64-pc-linux-gnu --target=riscv64-unknown-elf".
Type "show configuration" for configuration details.
For bug reporting instructions, please see:
<https://github.com/sifive/freedom-tools/issues>.
Find the GDB manual and other documentation resources online at:
    <http://www.gnu.org/software/gdb/documentation/>.

For help, type "help".
Type "apropos word" to search for commands related to "word"...
Reading symbols from zsbl.elf...
(gdb) set tdesc filename ../qemu_svn/gdb-xml/riscv-64bit-csr.xml
(gdb) target remote :1234
Remote debugging using :1234
_start () at zsbl/start.S:14
14        la t0, trap_entry
(gdb) load zsbl.elf
Loading section .text, size 0x28c2 lma 0x80000000
Loading section .rodata, size 0x2e00 lma 0x80002900
Loading section .sdata, size 0x20 lma 0x80005700
Start address 0x80000000, load size 22242
Transfer rate: 5430 KB/sec, 1710 bytes/write.
(gdb) n
15        csrw mtvec, t0
(gdb) c
Continuing.
####后记
QEMU does not have a high level design description document - only the source code tells the full story
本文仅是QEMU模拟器的简介和入门的使用方法，使用官方的发行版本做是案例介绍。当前做qemu的预研目的是模拟Testchip，基于RISC-V架构，遵循设计文档外扩硬件设备，添加代码模拟UART、SPI、GPIO、Timer等硬件设备，实现bare-metal和linux的加载启动。